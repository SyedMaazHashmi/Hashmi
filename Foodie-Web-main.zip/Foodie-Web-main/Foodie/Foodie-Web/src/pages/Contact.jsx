import React from "react";

const Contact = () => {
  return <div style={{fontWeight: 'bold'}}>Contact:- Call on this number: 021111244622</div>;
};

export default Contact;
